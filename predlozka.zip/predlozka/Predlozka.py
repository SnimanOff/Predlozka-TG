import telebot # pip install pyTelegramBotAPI
from openpyxl import load_workbook # pip install openpyxl
import logging 
import time 

wb = load_workbook(filename="") # Файл с админами (Указать свою директорию, по типу C://Users//debil//Desktop//admins.xlsx))
sheet = wb['admins'] # Страница с админами

need = ['voice', 'audio', 'photo', 'video', 'document', 'video_note', 'text'] # Нужный контент

els = ['location', 'contact', 'new_chat_members', 'left_chat_member', 'new_chat_title', 'new_chat_photo', # Не нужный контент
       'delete_chat_photo', 'group_chat_created', 'supergroup_chat_created', 'channel_chat_created',
       'migrate_to_chat_id', 'migrate_from_chat_id', 'pinned_message'] 


stop_bot = False # Переменная, которая останавливает бота (для админов)

bot = telebot.TeleBot('') # Токен бота (BotFather)


@bot.message_handler(commands=['stop'])  # Команда - стоп (остановка бота)
def handle_stop_command(message): # Остановка бота
    global stop_bot # Переменная для остановки бота
    stop_bot = True 
    bot.send_message(message.chat.id, "Бот остановлен") # Отправка сообщения ботом


@bot.message_handler(commands=['go']) # Команда - го (продолжение работы бота)
def handle_go_command(message): # Продолжние работы бота
    global stop_bot # Переменная для продолжения работы бота
    stop_bot = False
    bot.send_message(message.chat.id, "Бот продолжил работу") # Отправка сообщения ботом


@bot.message_handler(commands=['creator'])  # Создатель)) (при желании убрать ссылку на меня удалите 35-38 строчку)
def handle_start_command(message): # Продолжние работы бота
    bot.send_message(message.chat.id, "Бота создал @Sn1man")  # Отправка сообщения ботом


@bot.message_handler(commands=['start'])  # Команда - старт
def handle_start_command(message): # Основа бота
    bot.send_message(message.chat.id, "Отправь фото для передачи его администрации")  # Отправка сообщения ботом


@bot.message_handler(commands=['id'])  # Команда - id
def handle_start_command(message): # Основа бота
    chat_id = message.chat.id # определение айди человека (его нужно будет вписать в администрацию)
    bot.send_message(message.chat.id, f"{chat_id}")  # Отправка сообщения ботом


@bot.message_handler(content_types=els) # Команда по отклонению не нужного контента
def handle_other_files(message): # Основа бота
    if stop_bot: # Переменная для остановки бота (для администрации)
        return
    bot.send_message(message.chat.id, "Контент не поддерживается, пришлите фото") # Отправка сообщения ботом


@bot.message_handler(content_types=need) # Команда по отправке нужного контента
def handle_photo(message): # Основа бота
    if stop_bot: # Переменная для остановки бота (для администрации)
        return
    chat_ids = [row[0] for row in sheet.iter_rows(min_row=1, max_row=10, values_only=True)] # Определение айди администрации (при необходимости можете расширить max_row до бесконечности) 
    for admin_id in chat_ids: # Перебор айди администрации
        try:
            bot.forward_message(admin_id, message.chat.id, message.message_id) # Отправка 
            bot.send_message(message.chat.id, f"Отправлено") # Отправка сообщения ботом
        except Exception as e: # При возникновении ошибки
            if len(chat_ids) < 1: # Если айди администрации не определено
                bot.send_message(message.chat.id, f"Ошибка при отправке") # Отправка сообщения ботом (укажите администрацию в файлике от A1 до A10 (регулируется в строке 62))


# Запуск бота
if __name__ == '__main__':
    while True:
        try:
            bot.polling(none_stop=True) # Запуск бота
        except Exception as e: 
            logging.error(f"Ошибка в основном цикле бота: {e}") # Вывод ошибки в лог
            time.sleep(5) # Пауза